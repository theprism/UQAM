public class test {
    public static void main (String [] args){
        int select=0;
        do{
        select = Clavier.lireCharLn();
        System.out.println(select);
        }while (select!=1);
    }
}