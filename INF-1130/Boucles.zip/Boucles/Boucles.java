public class Boucles {
    public static void main (String [] args){
        int select=0;
        int erreurs=0;
        char lettre;
        boolean vLettre = true;
        int borneSup=0;
        int borneInf=0;
        int impair;
        int somme=0;
        int c=2;
        do {
            System.out.println(MessagesBoucles.CHOIX_1);
            System.out.println(MessagesBoucles.CHOIX_2);
            System.out.println(MessagesBoucles.CHOIX_9);
            System.out.println(MessagesBoucles.VOTRE_CHOIX);
            select = Clavier.lireInt();
            switch(select){
                case 1:
                    do{
                        System.out.println(MessagesBoucles.SAISIR_BORNE_INF);
                        borneInf = Clavier.lireInt();
                        if (borneInf<1){
                            System.out.println(MessagesBoucles.ERREUR);
                        }
                    }while(borneInf<1);
                    do{
                        System.out.println(MessagesBoucles.SAISIR_BORNE_SUP);
                        borneSup = Clavier.lireInt();
                        if (borneSup<=borneInf){
                            System.out.println(MessagesBoucles.ERREUR);
                        }
                    }while(borneSup<=borneInf);
                    System.out.println(MessagesBoucles.LISTE_DES_IMPAIRS);
                    for (int i=borneSup; i>borneInf; i=i-1){
                        if ((i%2)==0){
                            i=i-1;
                        }
                        somme = somme+i;
                        System.out.println(i);
                    }
                    System.out.println(MessagesBoucles.SOMME_DES_IMPAIRS);
                    System.out.println(somme);
                    break;
                case 2:
                    do{
                        System.out.println(MessagesBoucles.SAISIR_MAJUSCULE);
                        lettre = Clavier.lireCharLn();
                        if (!(lettre >='A' && lettre <= 'Z')){
                            System.out.println(MessagesBoucles.ERREUR);
                            erreurs++;
                        }else {
                            vLettre = !vLettre;
                        }
                    }while (vLettre);
                    System.out.println(MessagesBoucles.NOMBRE_ERREURS);
                    System.out.println(erreurs);
                    break;
                case 9:
                    break;
                default:
                    System.out.println(MessagesBoucles.CHOIX_NON_DISPONIBLE);
            }
        }while (select!=9);
    }
}
