public class MessagesBoucles {

    public static final String CHOIX_1
        = "1) Somme impairs";

    public static final String CHOIX_2
        = "2) Majuscules";

    public static final String CHOIX_9
        = "9) Quitter";

    public static final String VOTRE_CHOIX
        = "Votre choix:";

    public static final String SAISIR_BORNE_INF
        = "Saisir borne inferieure de l'interval:";

    public static final String SAISIR_BORNE_SUP
        = "Saisir borne superieure de l'interval:";

    public static final String NOMBRE_ERREURS
        = "Nombre d'erreurs:";

    public static final String SAISIR_MAJUSCULE
        = "Saisir une lettre majuscule:";

    public static final String ERREUR
        = "Erreur: Valeur non valide!";

    public static final String CHOIX_NON_DISPONIBLE
        = "Choix non disponible!";

    public static final String SOMME_DES_IMPAIRS
        = "Somme des impairs:";

    public static final String LISTE_DES_IMPAIRS
        = "Liste des impairs:";

}
