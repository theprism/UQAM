public class Tp2 {

    public static String appliquerCoup(String combinaison, String coup) {
        String result = "";
        int math;
        if (combinaison != null && coup != null) {
            if (coup.length() == combinaison.length() && !coup.isEmpty()) {
                for (int i = 0; i <= coup.length() - 1; i++) {
                    math = (combinaison.charAt(i) - coup.charAt(i));
                    if (math < 0) {
                        math = 0;
                    }
                    result = result + math;
                }
            }
        }
        return result;
    }

    public static boolean auMoinsUnCaracValide(String s, char min, char max){
        boolean valide = false;
        if (s != null) {
            for (int i = 0; i <= s.length() - 1 && !valide; i++) {
                if ((s.charAt(i) <= max) && (s.charAt(i) >= min)) {
                    valide = true;
                }
            }
        }
        return valide;
    }
    
    public static boolean tousLesCaracValides(String s, char min, char max){
        boolean valide = false;
        if (s != null) {
            valide = true;
            for (int i = 0; i <= s.length() - 1 && valide; i++) {
                if ((s.charAt(i) > max) || (s.charAt(i) < min)) {
                    valide = false;
                }
            }
        }
        return valide;
    }

    public static void main(String[] args) {
        String a = Clavier.lireString();
        char b = Clavier.lireCharLn();
        char c = Clavier.lireCharLn();
        System.out.println(Tp2.auMoinsUnCaracValide(a,b,c));
    }

}
